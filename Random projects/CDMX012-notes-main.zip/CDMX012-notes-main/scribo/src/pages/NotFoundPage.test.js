import { render, screen } from '@testing-library/react'
import NotFoundPage from './NotFoundPage'

// eslint-disable-next-line no-undef
describe('NotFoundPage', () => {
  // eslint-disable-next-line no-undef
  it('should render correctly', () => {
    render(<NotFoundPage />)
  })
})
