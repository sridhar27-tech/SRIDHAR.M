
const Dashboard = () => {
  return (
    <div>
      DashBoard
    </div>
  )
}

export default Dashboard
