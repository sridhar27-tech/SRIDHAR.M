import React from 'react'

const SubjectsCreate = () => {
  return (
    <div>
      Create
    </div>
  )
}

export default SubjectsCreate
